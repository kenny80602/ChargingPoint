export const UserInfo_NotFound = 501
export const SiteInfo_NotFound = 501
export const PoleInfo_NotFound =503
export const TransactionInfo_NotFound =504